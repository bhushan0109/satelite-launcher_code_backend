package com.satellite.aunchers.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.satellite.aunchers.entity.Satellite;
import com.satellite.aunchers.model.SatelliteData;
import com.satellite.aunchers.model.SatelliteResponse;
import com.satellite.aunchers.repository.SatelliteRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Service
public class SatelliteService {

	@Autowired
	private SatelliteRepository satelliteRepository;
	
	@PersistenceContext
    private EntityManager entityManager;


	public void fetchAndSaveSatellites() {

		RestTemplate restTemplate = new RestTemplate();
		String apiUrl = "https://isro.vercel.app/api/customer_satellites";
		SatelliteResponse response = restTemplate.getForObject(apiUrl, SatelliteResponse.class);

		// Save each satellite to the database
		if (response != null && response.getCustomer_satellites() != null) {
			for (SatelliteData satelliteData : response.getCustomer_satellites()) {
				Satellite satellite = new Satellite();
				satellite.setId(satelliteData.getId());
				satellite.setCountry(satelliteData.getCountry());

				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
				try {
					if (satelliteData.getLaunch_date() != null && !satelliteData.getLaunch_date().isEmpty()) {
						satellite.setLaunchDate(dateFormat.parse(satelliteData.getLaunch_date()));
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}

				if (satelliteData.getMass() != null && !satelliteData.getMass().isEmpty()) {
					try {
						satellite.setMass(Double.parseDouble(satelliteData.getMass()));
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
				}
				satellite.setLauncher(satelliteData.getLauncher());

				satelliteRepository.save(satellite);
			}
		}
	}

	  public List<Satellite> getAllSatellites() {
	        return satelliteRepository.findAll();
	    }

	    public Satellite getSatelliteById(String id) {
	        Optional<Satellite> satelliteOptional = satelliteRepository.findById(id);
	        return satelliteOptional.orElse(null);
	    }

	    public Satellite createSatellite(Satellite satellite) {
	        return satelliteRepository.save(satellite);
	    }

	    public Satellite updateSatellite(String id, Satellite satellite) {
	        if (!satelliteRepository.existsById(id)) {
	            return null; // Satellite with given id not found
	        }
	        satellite.setId(id);
	        return satelliteRepository.save(satellite);
	    }

	    public void deleteSatellite(String id) {
	        satelliteRepository.deleteById(id);
	    }

	    
	    public List<Satellite> searchSatellites(String id, String country, Date launchDate, Double mass, String launcher) {
	        StringBuilder queryStr = new StringBuilder("SELECT * FROM satellite s WHERE 1=1");

	        if (id != null) {
	            queryStr.append(" AND s.id = :id");
	        }
	        if (country != null) {
	            queryStr.append(" AND s.country = :country");
	        }
	        if (launchDate != null) {
	            queryStr.append(" AND s.launch_date = :launchDate");
	        }
	        if (mass != null) {
	            queryStr.append(" AND s.mass = :mass");
	        }
	        if (launcher != null) {
	            queryStr.append(" AND s.launcher = :launcher");
	        }

	        Query query = entityManager.createNativeQuery(queryStr.toString(), Satellite.class);

	        if (id != null) {
	            query.setParameter("id", id);
	        }
	        if (country != null) {
	            query.setParameter("country", country);
	        }
	        if (launchDate != null) {
	            query.setParameter("launchDate", launchDate);
	        }
	        if (mass != null) {
	            query.setParameter("mass", mass);
	        }
	        if (launcher != null) {
	            query.setParameter("launcher", launcher);
	        }

	        return query.getResultList();
	    }
}
