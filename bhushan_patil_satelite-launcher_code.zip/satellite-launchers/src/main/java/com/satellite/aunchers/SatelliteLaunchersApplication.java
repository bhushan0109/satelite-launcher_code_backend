package com.satellite.aunchers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SatelliteLaunchersApplication {

	public static void main(String[] args) {
		SpringApplication.run(SatelliteLaunchersApplication.class, args);
	}

}
