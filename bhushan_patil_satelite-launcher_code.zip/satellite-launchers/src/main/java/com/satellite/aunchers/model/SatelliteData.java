package com.satellite.aunchers.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SatelliteData {
    private String id;
    private String country;
    private String launch_date;
    private String mass;
    private String launcher;

}
