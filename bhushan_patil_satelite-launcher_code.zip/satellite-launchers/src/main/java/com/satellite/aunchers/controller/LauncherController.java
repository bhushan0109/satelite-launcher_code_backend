package com.satellite.aunchers.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.satellite.aunchers.service.LauncherService;

@RestController
@RequestMapping("/launchers")
public class LauncherController {
    @Autowired
    private LauncherService launcherService;

    @PostMapping("/fetch")
    public ResponseEntity<String> fetchLaunchers() {
        launcherService.fetchAndSaveLaunchers();
        return ResponseEntity.ok("Data fetched and saved successfully");
    }

}


