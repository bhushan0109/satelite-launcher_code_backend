package com.satellite.aunchers.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.satellite.aunchers.entity.Satellite;

@Repository
public interface SatelliteRepository extends JpaRepository<Satellite, String> {

//	@Query(value = "SELECT * FROM satellite s " +
//            "WHERE (:id IS NULL OR s.id = :id) " +
//            "AND (:country IS NULL OR s.country = :country) " +
//            "AND (:launchDate IS NULL OR s.launch_date = :launchDate) " +
//            "AND (:mass IS NULL OR s.mass = :mass) " +
//            "AND (:launcher IS NULL OR s.launcher = :launcher)", nativeQuery = true)
//List<Satellite> searchSatellites1(@Param("id") String id,
//                                 @Param("country") String country,
//                                 @Param("launchDate") Date launchDate,
//                                 @Param("mass") Double mass,
//                                 @Param("launcher") String launcher);
	
	@Query(value = "SELECT * FROM satellite s " +
            "WHERE (:id IS NULL OR s.id = :id)", nativeQuery = true)
    List<Satellite> searchSatellites(@Param("id") String id);
	 
	 
}