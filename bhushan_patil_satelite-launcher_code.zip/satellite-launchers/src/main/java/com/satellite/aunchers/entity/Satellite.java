package com.satellite.aunchers.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Satellite {

	@Id
	private String id;
	private String country;

	@Temporal(TemporalType.DATE)
	private Date launchDate;
	private double mass;
	private String launcher;

}
