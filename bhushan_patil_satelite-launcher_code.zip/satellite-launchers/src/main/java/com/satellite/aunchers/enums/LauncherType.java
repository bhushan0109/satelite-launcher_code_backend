package com.satellite.aunchers.enums;

public enum LauncherType {
    NEW,
    OLD,
    DEGRADED
}