package com.satellite.aunchers.entity;

import java.util.Date;

import com.satellite.aunchers.enums.LauncherType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SatelliteLauncher {
    @Id
    private String id;
    @Enumerated(EnumType.STRING)
    private LauncherType type;
    private Date registeredOn;
}