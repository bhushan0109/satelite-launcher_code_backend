package com.satellite.aunchers.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.satellite.aunchers.entity.SatelliteLauncher;
import com.satellite.aunchers.model.LauncherData;
import com.satellite.aunchers.model.LauncherResponse;
import com.satellite.aunchers.repository.LauncherRepository;

@Service
public class LauncherService {

	@Autowired
	private LauncherRepository launcherRepository;

	public void fetchAndSaveLaunchers() {

		RestTemplate restTemplate = new RestTemplate();
		String apiUrl = "https://isro.vercel.app/api/launchers";
		LauncherResponse response = restTemplate.getForObject(apiUrl, LauncherResponse.class);

		if (response != null && response.getLaunchers() != null) {
			for (LauncherData launcherData : response.getLaunchers()) {
				SatelliteLauncher launcher = new SatelliteLauncher();
				launcher.setId(launcherData.getId());

				launcherRepository.save(launcher);
			}
		}
	}
}
